document.getElementById('application').innerHTML = localStorage.getItem(
    'final-message'
);
